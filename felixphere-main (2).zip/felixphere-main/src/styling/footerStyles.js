const foot = {
    width:"80%",
    marginLeft:"auto",
    marginRight:"auto"
  }
  